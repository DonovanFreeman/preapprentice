
#include <stdio.h>

int main ()
{
    printf("Hello World!\n\n\n\n\n");
    return 0;
}