print("Hello World! from Python!\n")

print("I will show you some data!!")

myname = "Donovan Freeman"
age = "18"
eyes= "brown"
print(f"Hello, {myname}. You are {age} years old!")
print(f"You have {eyes} eyes!!!")
